# Mohini 
<a href="https://ibb.co/VW5HGfj"><img src="https://i.ibb.co/GvNsDzx/logo.jpg" alt="logo" border="0"></a>
<br>
# Commands
## (Copy Command & Paste in Termux)
<br>
<br>
<li>cd;apt update -y;apt upgrade -y;apt install git;git clone https://github.com/Bhai4You/Mohini;cd Mohini;chmod +x mohini.sh;bash mohini.sh
<br>
